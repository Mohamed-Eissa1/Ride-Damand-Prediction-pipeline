"""
tests/integration/test_pipeline_health.py

Runs against the live docker-compose stack (see .github/workflows/ci.yml,
job "integration-tests"). Unlike tests/unit, these require real running
containers — Postgres and the backend API must actually be reachable.

Kept intentionally small: this validates the seam between the API and a
real Postgres instance (that migrations ran, that the connection pool
works), not full pipeline correctness — that would require also running
Kafka producer + Spark + ML scoring for long enough to generate data,
which is exercised manually per docs/deployment_guide, not on every CI run.
"""

import os

import requests

API_BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000")


def test_health_endpoint_reports_database_connected():
    response = requests.get(f"{API_BASE_URL}/v1/health", timeout=10)
    assert response.status_code == 200
    body = response.json()
    assert body["database_connected"] is True


def test_zones_endpoint_returns_seeded_zones():
    api_key = os.environ.get("API_KEY", "test-api-key")
    response = requests.get(f"{API_BASE_URL}/v1/zones", headers={"x-api-key": api_key}, timeout=10)
    assert response.status_code == 200
    zones = response.json()
    # db/migrations/002_seed_zones.sql seeds exactly 8 demo zones.
    assert len(zones) == 8
    assert any(z["zone_name"] == "Downtown" for z in zones)
