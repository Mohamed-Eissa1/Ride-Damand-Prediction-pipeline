"""
tests/unit/test_api.py

Tests the FastAPI routing, auth, and error-handling behavior with the
database layer mocked out via monkeypatching — matching Section 28.1
(Unit Testing): "FastAPI endpoint logic against a test database" is
approximated here with an in-memory fake so tests run fast and need no
real PostgreSQL instance.
"""

import os
import sys

sys.path.append("/home/claude/ride-demand-pipeline")

os.environ.setdefault("POSTGRES_DB", "test_db")
os.environ.setdefault("POSTGRES_USER", "test_user")
os.environ.setdefault("POSTGRES_PASSWORD", "test_password")
os.environ.setdefault("API_KEY", "test-api-key")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from backend import database, main  # noqa: E402

VALID_HEADERS = {"x-api-key": "test-api-key"}


@pytest.fixture(autouse=True)
def patch_database(monkeypatch):
    """Replaces every database call with an in-memory fake for the test run."""
    monkeypatch.setattr(database, "check_connection", lambda: True)
    monkeypatch.setattr(
        database,
        "fetch_all_zones",
        lambda: [
            {"zone_id": 1, "zone_name": "Downtown", "boundary_lat": 30.04, "boundary_lng": 31.23},
        ],
    )
    monkeypatch.setattr(
        database,
        "fetch_latest_predictions",
        lambda: [
            {
                "zone_id": 1,
                "zone_name": "Downtown",
                "predicted_demand": 42.5,
                "window_start": "2026-07-07T18:00:00Z",
                "window_end": "2026-07-07T18:15:00Z",
                "model_version": "v1.0",
            }
        ],
    )

    def fake_fetch_one(zone_id: int):
        if zone_id == 1:
            return {
                "zone_id": 1,
                "zone_name": "Downtown",
                "predicted_demand": 42.5,
                "window_start": "2026-07-07T18:00:00Z",
                "window_end": "2026-07-07T18:15:00Z",
                "model_version": "v1.0",
            }
        return None

    monkeypatch.setattr(database, "fetch_latest_prediction_for_zone", fake_fetch_one)
    monkeypatch.setattr(database, "init_pool", lambda *args, **kwargs: None)


@pytest.fixture
def client():
    return TestClient(main.app)


def test_health_does_not_require_api_key(client):
    response = client.get("/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_zones_requires_api_key(client):
    response = client.get("/v1/zones")
    assert response.status_code == 401


def test_zones_with_valid_key_returns_data(client):
    response = client.get("/v1/zones", headers=VALID_HEADERS)
    assert response.status_code == 200
    body = response.json()
    assert body[0]["zone_name"] == "Downtown"


def test_predictions_all_returns_data(client):
    response = client.get("/v1/predictions/all", headers=VALID_HEADERS)
    assert response.status_code == 200
    assert response.json()[0]["predicted_demand"] == 42.5


def test_prediction_for_known_zone(client):
    response = client.get("/v1/predictions/zone/1", headers=VALID_HEADERS)
    assert response.status_code == 200
    assert response.json()["zone_id"] == 1


def test_prediction_for_unknown_zone_returns_404(client):
    response = client.get("/v1/predictions/zone/999", headers=VALID_HEADERS)
    assert response.status_code == 404
