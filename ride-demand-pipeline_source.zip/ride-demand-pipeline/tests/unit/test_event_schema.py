"""
tests/unit/test_event_schema.py

Unit tests for producer/event_schema.py — the schema contract that every
other component (Spark, consumer, DLQ routing) relies on.
"""

import sys

sys.path.append("/home/claude/ride-demand-pipeline")

import pytest  # noqa: E402
from producer.event_schema import RideRequestEvent, InvalidRideEventError  # noqa: E402


def test_create_generates_valid_event():
    event = RideRequestEvent.create(zone_id=3, rider_id="rider_00042")
    event.validate()  # should not raise
    assert event.zone_id == 3
    assert event.rider_id == "rider_00042"
    assert event.event_id  # non-empty UUID string


def test_to_dict_round_trip():
    event = RideRequestEvent.create(zone_id=1, rider_id="rider_00001")
    data = event.to_dict()
    rebuilt = RideRequestEvent.from_dict(data)
    assert rebuilt == event


@pytest.mark.parametrize("bad_zone_id", [0, -1, "not_an_int"])
def test_validate_rejects_invalid_zone_id(bad_zone_id):
    event = RideRequestEvent(
        event_id="00000000-0000-0000-0000-000000000000",
        zone_id=bad_zone_id,
        rider_id="rider_00001",
        event_time="2026-07-07T18:00:00Z",
    )
    with pytest.raises(InvalidRideEventError):
        event.validate()


def test_validate_rejects_empty_rider_id():
    event = RideRequestEvent(
        event_id="00000000-0000-0000-0000-000000000000",
        zone_id=1,
        rider_id="",
        event_time="2026-07-07T18:00:00Z",
    )
    with pytest.raises(InvalidRideEventError):
        event.validate()


def test_from_dict_rejects_missing_fields():
    with pytest.raises(InvalidRideEventError):
        RideRequestEvent.from_dict({"zone_id": 1, "rider_id": "rider_00001"})  # missing event_id/event_time
