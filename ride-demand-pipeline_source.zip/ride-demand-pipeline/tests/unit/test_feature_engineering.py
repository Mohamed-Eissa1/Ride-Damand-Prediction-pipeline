"""
tests/unit/test_feature_engineering.py

Unit tests for streaming/feature_engineering.py.

is_weekend_from_day_of_week() is deliberately pure Python (no Spark
dependency) so it can be tested directly and fast, without a SparkSession.
The full windowing/aggregation pipeline is exercised separately in
tests/integration/, since it genuinely requires a running SparkSession.
"""

import sys

sys.path.append("/home/claude/ride-demand-pipeline")

import pytest  # noqa: E402

pyspark = pytest.importorskip("pyspark", reason="pyspark not installed in this environment")

from streaming.feature_engineering import is_weekend_from_day_of_week  # noqa: E402


@pytest.mark.parametrize(
    "day_of_week,expected",
    [
        (1, False),  # Sunday
        (2, False),  # Monday
        (3, False),  # Tuesday
        (4, False),  # Wednesday
        (5, False),  # Thursday
        (6, True),  # Friday
        (7, True),  # Saturday
    ],
)
def test_is_weekend_from_day_of_week(day_of_week, expected):
    assert is_weekend_from_day_of_week(day_of_week) is expected
