"""
tests/unit/test_model.py

Unit tests for ml/model.py. Uses a tiny, deterministic in-memory
estimator rather than a real trained model, so the test validates the
wrapper's contract (missing-feature errors, non-negative clamping,
save/load round trip) without depending on training data.
"""

import sys

sys.path.append("/home/claude/ride-demand-pipeline")

import pytest  # noqa: E402
from sklearn.linear_model import LinearRegression  # noqa: E402

from ml.model import DemandModel, ModelMetadata  # noqa: E402


def _make_dummy_model() -> DemandModel:
    estimator = LinearRegression()
    # Two trivial training rows so LinearRegression has something to fit.
    X = [[1, 1.0, 8, 0, 1.0], [2, 2.0, 9, 1, 2.0]]
    y = [1, 2]
    estimator.fit(X, y)
    metadata = ModelMetadata(version="vtest", trained_at="2026-07-07T00:00:00Z", mae=0.1, rmse=0.1, r2=0.9)
    return DemandModel(estimator, metadata)


def test_predict_one_returns_non_negative_float():
    model = _make_dummy_model()
    features = {
        "ride_count": 5,
        "rolling_avg_15m": 4.5,
        "hour_of_day": 18,
        "is_weekend": True,
        "zone_historical_avg": 6.0,
    }
    prediction = model.predict_one(features)
    assert isinstance(prediction, float)
    assert prediction >= 0.0


def test_predict_one_raises_on_missing_feature():
    model = _make_dummy_model()
    incomplete_features = {"ride_count": 5}  # missing everything else
    with pytest.raises(ValueError, match="Missing required features"):
        model.predict_one(incomplete_features)


def test_predict_one_handles_null_rolling_and_historical_avg():
    model = _make_dummy_model()
    features = {
        "ride_count": 3,
        "rolling_avg_15m": None,  # e.g. first-ever window for a zone
        "hour_of_day": 10,
        "is_weekend": False,
        "zone_historical_avg": None,
    }
    prediction = model.predict_one(features)
    assert isinstance(prediction, float)


def test_save_and_load_round_trip(tmp_path):
    model = _make_dummy_model()
    model.save(model_dir=str(tmp_path))

    loaded = DemandModel.load(str(tmp_path / "demand_model_vtest.pkl"))
    assert loaded.metadata.version == "vtest"
    assert loaded.metadata.mae == pytest.approx(0.1)

    features = {
        "ride_count": 5,
        "rolling_avg_15m": 4.5,
        "hour_of_day": 18,
        "is_weekend": True,
        "zone_historical_avg": 6.0,
    }
    # Loaded model should produce the same prediction as the original.
    assert loaded.predict_one(features) == pytest.approx(model.predict_one(features))
