"""
dashboard/app.py

Operational dashboard for the ops team (Section 21, Dashboard).

All business logic lives in the API — this file only fetches and
renders. It polls /v1/predictions/all on a cached interval so many
simultaneous dashboard sessions don't hammer the backend with duplicate
requests (Section 21.4, Monitoring / Bottleneck mitigation).
"""

import os
import sys
from datetime import datetime, timezone

import pandas as pd
import requests
import streamlit as st

sys.path.append("/app")
from common.config import load_api_config  # noqa: E402

st.set_page_config(page_title="Ride Demand Prediction — Ops Dashboard", layout="wide")

API_BASE_URL = os.environ.get("API_BASE_URL", "http://backend:8000")
CACHE_TTL_SECONDS = 5


def _headers() -> dict:
    api_config = load_api_config()
    return {"x-api-key": api_config.api_key}


@st.cache_data(ttl=CACHE_TTL_SECONDS)
def fetch_predictions() -> tuple[pd.DataFrame, datetime, bool]:
    try:
        response = requests.get(f"{API_BASE_URL}/v1/predictions/all", headers=_headers(), timeout=5)
        response.raise_for_status()
        df = pd.DataFrame(response.json())
        return df, datetime.now(timezone.utc), True
    except requests.RequestException:
        return pd.DataFrame(), datetime.now(timezone.utc), False


@st.cache_data(ttl=60)
def fetch_zones() -> pd.DataFrame:
    try:
        response = requests.get(f"{API_BASE_URL}/v1/zones", headers=_headers(), timeout=5)
        response.raise_for_status()
        return pd.DataFrame(response.json())
    except requests.RequestException:
        return pd.DataFrame()


def render_header(last_updated: datetime, api_healthy: bool) -> None:
    col1, col2 = st.columns([4, 1])
    with col1:
        st.title("Ride Demand Prediction — Operations Dashboard")
    with col2:
        staleness = (datetime.now(timezone.utc) - last_updated).total_seconds()
        if not api_healthy:
            st.error("API unreachable — showing no data")
        elif staleness > CACHE_TTL_SECONDS * 3:
            st.warning(f"Data may be stale ({int(staleness)}s old)")
        else:
            st.success("Live")


def render_kpis(predictions_df: pd.DataFrame) -> None:
    col1, col2, col3 = st.columns(3)
    total_predicted = predictions_df["predicted_demand"].sum() if not predictions_df.empty else 0
    zones_covered = predictions_df["zone_id"].nunique() if not predictions_df.empty else 0
    top_zone = (
        predictions_df.sort_values("predicted_demand", ascending=False).iloc[0]["zone_name"]
        if not predictions_df.empty
        else "—"
    )
    col1.metric("Total predicted demand (next window)", f"{total_predicted:.0f} rides")
    col2.metric("Zones covered", zones_covered)
    col3.metric("Highest-demand zone", top_zone)


def render_top_zones_chart(predictions_df: pd.DataFrame) -> None:
    st.subheader("Top zones by predicted demand")
    if predictions_df.empty:
        st.info("No prediction data available yet.")
        return
    top5 = predictions_df.sort_values("predicted_demand", ascending=False).head(5)
    st.bar_chart(top5.set_index("zone_name")["predicted_demand"])


def render_predictions_table(predictions_df: pd.DataFrame) -> None:
    st.subheader("All zone predictions")
    if predictions_df.empty:
        st.info("No prediction data available yet.")
        return
    display_df = predictions_df[["zone_name", "predicted_demand", "window_start", "window_end", "model_version"]]
    st.dataframe(display_df, use_container_width=True)


def render_zone_map(predictions_df: pd.DataFrame, zones_df: pd.DataFrame) -> None:
    st.subheader("Zone demand map")
    if predictions_df.empty or zones_df.empty:
        st.info("Map will appear once zone and prediction data are both available.")
        return
    merged = predictions_df.merge(zones_df, on="zone_id", how="left")
    map_df = merged.rename(columns={"boundary_lat": "lat", "boundary_lng": "lon"})[["lat", "lon"]]
    st.map(map_df)


def main() -> None:
    predictions_df, last_updated, api_healthy = fetch_predictions()
    zones_df = fetch_zones()

    render_header(last_updated, api_healthy)
    render_kpis(predictions_df)

    left, right = st.columns(2)
    with left:
        render_top_zones_chart(predictions_df)
    with right:
        render_zone_map(predictions_df, zones_df)

    render_predictions_table(predictions_df)

    st.caption(
        f"Last refreshed: {last_updated.strftime('%Y-%m-%d %H:%M:%S UTC')} — auto-refreshes every {CACHE_TTL_SECONDS}s"
    )


if __name__ == "__main__":
    main()
