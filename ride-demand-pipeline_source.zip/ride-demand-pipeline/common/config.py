"""
common/config.py

Centralized configuration loader.

Every service (producer, Spark job, ML scorer, FastAPI, Streamlit) imports
this module instead of reading os.environ directly. This guarantees:
  - one place to see every environment variable the system depends on
  - sane defaults for local development
  - a single point of failure if a required variable is missing, instead of
    a service crashing deep inside business logic with a confusing error.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


def _get_env(name: str, default: str | None = None, required: bool = False) -> str:
    value = os.environ.get(name, default)
    if required and not value:
        raise RuntimeError(
            f"Missing required environment variable '{name}'. " f"Check your .env file against .env.example."
        )
    return value


@dataclass(frozen=True)
class KafkaConfig:
    bootstrap_servers: str
    topic_ride_requests: str
    topic_dead_letter: str
    consumer_group_id: str


@dataclass(frozen=True)
class DatabaseConfig:
    host: str
    port: int
    name: str
    user: str
    password: str

    @property
    def sqlalchemy_url(self) -> str:
        return f"postgresql+psycopg2://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"

    @property
    def jdbc_url(self) -> str:
        # Used by the Spark job, which writes via the JDBC driver rather than SQLAlchemy.
        return f"jdbc:postgresql://{self.host}:{self.port}/{self.name}"


@dataclass(frozen=True)
class MLConfig:
    model_path: str
    model_version: str
    prediction_window_minutes: int


@dataclass(frozen=True)
class APIConfig:
    api_key: str
    host: str
    port: int


def load_kafka_config() -> KafkaConfig:
    return KafkaConfig(
        bootstrap_servers=_get_env("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
        topic_ride_requests=_get_env("KAFKA_TOPIC_RIDE_REQUESTS", "ride-requests"),
        topic_dead_letter=_get_env("KAFKA_TOPIC_DLQ", "ride-requests-dlq"),
        consumer_group_id=_get_env("KAFKA_CONSUMER_GROUP", "ride-demand-spark-consumer"),
    )


def load_database_config() -> DatabaseConfig:
    return DatabaseConfig(
        host=_get_env("POSTGRES_HOST", "localhost"),
        port=int(_get_env("POSTGRES_PORT", "5432")),
        name=_get_env("POSTGRES_DB", "ride_demand", required=True),
        user=_get_env("POSTGRES_USER", "ride_demand_app", required=True),
        password=_get_env("POSTGRES_PASSWORD", required=True),
    )


def load_ml_config() -> MLConfig:
    return MLConfig(
        model_path=_get_env("ML_MODEL_PATH", "/app/ml/artifacts/demand_model_latest.pkl"),
        model_version=_get_env("ML_MODEL_VERSION", "v1.0"),
        prediction_window_minutes=int(_get_env("ML_PREDICTION_WINDOW_MINUTES", "15")),
    )


def load_api_config() -> APIConfig:
    return APIConfig(
        api_key=_get_env("API_KEY", required=True),
        host=_get_env("API_HOST", "0.0.0.0"),
        port=int(_get_env("API_PORT", "8000")),
    )
