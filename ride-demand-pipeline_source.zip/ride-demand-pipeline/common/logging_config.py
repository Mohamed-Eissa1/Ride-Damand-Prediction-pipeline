"""
common/logging_config.py

Structured logging setup shared across all services.

Design goals (see Technical Documentation, Section 25 - Logging):
  - Every log line carries a timestamp, severity, service name, and message,
    so a single event can be traced across producer -> Spark -> API logs.
  - JSON-formatted output in non-local environments, so logs are easy to
    ship to a log aggregator (ELK, CloudWatch, etc.) later without
    re-instrumenting the codebase.
  - Human-readable plain text in local development, for fast debugging.
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "service": getattr(record, "service", "unknown"),
            "message": record.getMessage(),
            "logger": record.name,
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def get_logger(service_name: str) -> logging.Logger:
    """
    Returns a logger pre-configured for the given service.

    Usage:
        logger = get_logger("producer")
        logger.info("Published ride request event", extra={"zone_id": 7})
    """
    logger = logging.getLogger(service_name)
    if logger.handlers:
        # Avoid attaching duplicate handlers if get_logger() is called more than once.
        return logger

    log_level = os.environ.get("LOG_LEVEL", "INFO").upper()
    logger.setLevel(log_level)

    handler = logging.StreamHandler(sys.stdout)
    use_json = os.environ.get("LOG_FORMAT", "json").lower() == "json"

    if use_json:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(
            logging.Formatter(
                fmt=f"%(asctime)s | %(levelname)s | {service_name} | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )

    logger.addHandler(handler)

    # Inject the service name into every record automatically.
    old_factory = logging.getLogRecordFactory()

    def record_factory(*args, **kwargs):
        record = old_factory(*args, **kwargs)
        record.service = service_name
        return record

    logging.setLogRecordFactory(record_factory)
    return logger
