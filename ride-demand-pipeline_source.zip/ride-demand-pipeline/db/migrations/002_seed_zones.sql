-- db/migrations/002_seed_zones.sql
--
-- Seed a small set of demo zones so the pipeline has reference data to
-- join against immediately after a fresh docker compose up.
-- Safe to re-run: ON CONFLICT DO NOTHING avoids duplicate-key errors.

BEGIN;

INSERT INTO zones (zone_id, zone_name, boundary_lat, boundary_lng) VALUES
    (1, 'Downtown',        30.0444, 31.2357),
    (2, 'Nasr City',       30.0626, 31.3219),
    (3, 'Maadi',           29.9602, 31.2569),
    (4, 'Heliopolis',      30.0808, 31.3231),
    (5, 'Giza Center',     30.0131, 31.2089),
    (6, 'New Cairo',       30.0300, 31.4700),
    (7, '6th of October',  29.9660, 30.9232),
    (8, 'Zamalek',         30.0616, 31.2197)
ON CONFLICT (zone_id) DO NOTHING;

COMMIT;
