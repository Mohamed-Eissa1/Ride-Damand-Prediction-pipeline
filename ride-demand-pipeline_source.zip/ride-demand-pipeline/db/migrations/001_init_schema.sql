-- db/migrations/001_init_schema.sql
--
-- Initial schema for the Real-Time Ride Demand Prediction Pipeline.
-- Matches the ER diagram in Technical Documentation, Section 19 (Database Design).
--
-- Run order: this file must run before any other migration.
-- Idempotent: safe to re-run thanks to IF NOT EXISTS guards.

BEGIN;

-- ---------------------------------------------------------------------------
-- zones: reference data for every geographic zone the system tracks demand for
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS zones (
    zone_id       INTEGER PRIMARY KEY,
    zone_name     VARCHAR(120) NOT NULL,
    boundary_lat  DOUBLE PRECISION NOT NULL,
    boundary_lng  DOUBLE PRECISION NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- ride_events: raw / lightly-cleaned historical ride request events.
-- This table is a landing zone for auditing and offline model retraining;
-- the live pipeline reads from Kafka directly, not from this table.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ride_events (
    event_id    UUID PRIMARY KEY,
    zone_id     INTEGER NOT NULL REFERENCES zones (zone_id),
    rider_id    VARCHAR(64) NOT NULL,
    event_time  TIMESTAMPTZ NOT NULL,
    ingested_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ride_events_zone_time
    ON ride_events (zone_id, event_time);

-- ---------------------------------------------------------------------------
-- zone_features: windowed aggregates produced by the Spark streaming job.
-- One row per (zone_id, window_start) — upserted as windows finalize.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS zone_features (
    feature_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    zone_id            INTEGER NOT NULL REFERENCES zones (zone_id),
    window_start       TIMESTAMPTZ NOT NULL,
    window_end         TIMESTAMPTZ NOT NULL,
    ride_count         INTEGER NOT NULL,
    rolling_avg_15m    DOUBLE PRECISION,
    hour_of_day        SMALLINT NOT NULL,
    is_weekend         BOOLEAN NOT NULL,
    zone_historical_avg DOUBLE PRECISION,
    computed_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_zone_window UNIQUE (zone_id, window_start)
);

CREATE INDEX IF NOT EXISTS idx_zone_features_zone_window
    ON zone_features (zone_id, window_start);

-- ---------------------------------------------------------------------------
-- zone_predictions: model output, served by the API.
-- One row per (zone_id, window_start, model_version) — upserted on rescoring.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS zone_predictions (
    prediction_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    zone_id           INTEGER NOT NULL REFERENCES zones (zone_id),
    predicted_demand  DOUBLE PRECISION NOT NULL,
    window_start      TIMESTAMPTZ NOT NULL,
    window_end        TIMESTAMPTZ NOT NULL,
    model_version     VARCHAR(32) NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_zone_window_model UNIQUE (zone_id, window_start, model_version)
);

CREATE INDEX IF NOT EXISTS idx_zone_predictions_zone_window
    ON zone_predictions (zone_id, window_start);

COMMIT;
