-- db/migrations/003_zone_features_staging.sql
--
-- Staging table used by streaming/spark_job.py: each micro-batch is written
-- here first (fast bulk JDBC write), then merged into zone_features via a
-- single ON CONFLICT upsert statement. Keeping this separate from the
-- final table avoids row-by-row upserts from Spark, which do not scale.

BEGIN;

CREATE TABLE IF NOT EXISTS zone_features_staging (
    zone_id             INTEGER NOT NULL,
    window_start        TIMESTAMPTZ NOT NULL,
    window_end          TIMESTAMPTZ NOT NULL,
    ride_count          INTEGER NOT NULL,
    rolling_avg_15m     DOUBLE PRECISION,
    hour_of_day         SMALLINT NOT NULL,
    is_weekend          BOOLEAN NOT NULL,
    zone_historical_avg DOUBLE PRECISION
);

COMMIT;
