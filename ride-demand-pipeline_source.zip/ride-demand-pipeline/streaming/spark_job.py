"""
streaming/spark_job.py

Entry point for the PySpark Structured Streaming job.

Reads from Kafka -> parses & cleans events -> windows + aggregates ->
computes derived and rolling features -> upserts into the zone_features
table in PostgreSQL. Invalid events are routed to a dead-letter Kafka
topic instead of being dropped silently (Section 27, Error Handling).

Enterprise practices demonstrated here:
  - Checkpointing to durable storage so a restart resumes exactly where
    the job left off (combined with Kafka offset tracking, this avoids
    both data loss and duplicate processing).
  - foreachBatch used for the Postgres write path, since Structured
    Streaming's native sinks do not support upsert semantics — this is
    also where the batch-only rolling-average calculation is applied.
  - Idempotent writes (ON CONFLICT DO UPDATE) so re-processing the same
    window after a restart does not create duplicate rows.
"""

import sys

from pyspark.sql import DataFrame, SparkSession

sys.path.append("/app")
from common.config import load_kafka_config, load_database_config  # noqa: E402
from common.logging_config import get_logger  # noqa: E402
from streaming.feature_engineering import build_feature_pipeline, compute_rolling_average  # noqa: E402

logger = get_logger("spark-streaming")

CHECKPOINT_LOCATION = "/app/checkpoints/zone_features"


def build_spark_session() -> SparkSession:
    return (
        SparkSession.builder.appName("ride-demand-feature-engineering")
        .config("spark.sql.shuffle.partitions", "8")  # tuned down from the 200 default for demo-scale data
        .getOrCreate()
    )


def write_batch_to_postgres(batch_df: DataFrame, batch_id: int) -> None:
    """
    Called once per micro-batch by foreachBatch. Applies the rolling
    average (a batch-only operation) and upserts into Postgres via the
    JDBC driver, using a staging-table + ON CONFLICT pattern for
    idempotency.
    """
    if batch_df.rdd.isEmpty():
        logger.info(f"Batch {batch_id}: no new windows to write, skipping")
        return

    db_config = load_database_config()
    enriched = compute_rolling_average(batch_df)

    row_count = enriched.count()
    logger.info(f"Batch {batch_id}: writing {row_count} zone_features rows")

    try:
        (
            enriched.withColumn(
                "zone_historical_avg", enriched["rolling_avg_15m"]
            )  # placeholder until long-run history is built up
            .write.format("jdbc")
            .option("url", db_config.jdbc_url)
            .option("dbtable", "zone_features_staging")
            .option("user", db_config.user)
            .option("password", db_config.password)
            .option("driver", "org.postgresql.Driver")
            .mode("overwrite")
            .save()
        )
        _upsert_staging_into_final(db_config)
        logger.info(f"Batch {batch_id}: write completed successfully")
    except Exception:
        logger.exception(f"Batch {batch_id}: failed to write to Postgres")
        raise  # re-raise so Spark retries the batch rather than silently losing it


def _upsert_staging_into_final(db_config) -> None:
    """
    Merges zone_features_staging into zone_features using ON CONFLICT,
    then truncates the staging table. Kept as a single, auditable SQL
    step rather than issuing per-row upserts from Spark.
    """
    import psycopg2

    conn = psycopg2.connect(
        host=db_config.host,
        port=db_config.port,
        dbname=db_config.name,
        user=db_config.user,
        password=db_config.password,
    )
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO zone_features (
                    zone_id, window_start, window_end, ride_count,
                    rolling_avg_15m, hour_of_day, is_weekend, zone_historical_avg
                )
                SELECT zone_id, window_start, window_end, ride_count,
                       rolling_avg_15m, hour_of_day, is_weekend, zone_historical_avg
                FROM zone_features_staging
                ON CONFLICT (zone_id, window_start) DO UPDATE SET
                    ride_count = EXCLUDED.ride_count,
                    rolling_avg_15m = EXCLUDED.rolling_avg_15m,
                    hour_of_day = EXCLUDED.hour_of_day,
                    is_weekend = EXCLUDED.is_weekend,
                    zone_historical_avg = EXCLUDED.zone_historical_avg,
                    computed_at = now();
                TRUNCATE TABLE zone_features_staging;
            """)
        conn.commit()
    finally:
        conn.close()


def write_invalid_events_to_dlq(invalid_df: DataFrame, batch_id: int) -> None:
    """Routes malformed events to the dead-letter Kafka topic instead of dropping them."""
    if invalid_df.rdd.isEmpty():
        return

    kafka_config = load_kafka_config()
    count = invalid_df.count()
    logger.warning(f"Batch {batch_id}: routing {count} invalid events to DLQ")

    (
        invalid_df.selectExpr("to_json(struct(*)) AS value")
        .write.format("kafka")
        .option("kafka.bootstrap.servers", kafka_config.bootstrap_servers)
        .option("topic", kafka_config.topic_dead_letter)
        .save()
    )


def run() -> None:
    kafka_config = load_kafka_config()
    spark = build_spark_session()
    spark.sparkContext.setLogLevel("WARN")

    logger.info(f"Subscribing to Kafka topic '{kafka_config.topic_ride_requests}'")

    raw_stream = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", kafka_config.bootstrap_servers)
        .option("subscribe", kafka_config.topic_ride_requests)
        .option("startingOffsets", "latest")
        .option("failOnDataLoss", "false")
        .load()
    )

    features_df, invalid_df = build_feature_pipeline(raw_stream)

    features_query = (
        features_df.writeStream.foreachBatch(write_batch_to_postgres)
        .option("checkpointLocation", CHECKPOINT_LOCATION)
        .outputMode("update")
        .start()
    )

    invalid_query = (
        invalid_df.writeStream.foreachBatch(write_invalid_events_to_dlq)
        .option("checkpointLocation", CHECKPOINT_LOCATION + "_dlq")
        .outputMode("append")
        .start()
    )

    logger.info(
        f"Streaming job started. features_query id={features_query.id} "
        f"invalid_query id={invalid_query.id}. Awaiting termination..."
    )
    spark.streams.awaitAnyTermination()


if __name__ == "__main__":
    run()
