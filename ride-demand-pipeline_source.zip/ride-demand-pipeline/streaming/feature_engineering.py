"""
streaming/feature_engineering.py

Transforms the raw ride-request event stream into ML-ready features.

Matches Technical Documentation, Section 17 (Spark Structured Streaming):
  17.3 Aggregation      -> compute_windowed_aggregates()
  17.4 Cleaning         -> clean_events()
  17.5 Feature Engineering -> add_derived_features(), compute_rolling_average()

Design note: pure, Spark-independent logic (e.g. is_weekend_from_day_of_week)
is kept as standalone functions so it can be unit tested directly, without
needing a running SparkSession. The Spark-dependent transformations call
into these pure functions via UDFs only where Spark has no native
equivalent — native pyspark.sql.functions are preferred wherever possible
for performance.
"""

from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Must match producer/event_schema.py exactly.
RIDE_EVENT_SCHEMA = StructType(
    [
        StructField("event_id", StringType(), nullable=False),
        StructField("zone_id", IntegerType(), nullable=False),
        StructField("rider_id", StringType(), nullable=False),
        StructField("event_time", StringType(), nullable=False),
    ]
)

WINDOW_DURATION = "5 minutes"
SLIDE_DURATION = "1 minute"
WATERMARK_DELAY = "2 minutes"
ROLLING_WINDOW_MINUTES = 15


def is_weekend_from_day_of_week(day_of_week: int) -> bool:
    """
    Pure function, unit-testable without Spark.

    Spark's dayofweek() returns 1=Sunday ... 7=Saturday.
    In this project's regional context, the weekend is Friday and Saturday
    (days 6 and 7), matching the Egypt-based demo zones seeded in
    db/migrations/002_seed_zones.sql.
    """
    return day_of_week in (6, 7)


def parse_raw_events(raw_df: DataFrame) -> DataFrame:
    """Parses the raw Kafka value column (bytes) into typed columns."""
    return (
        raw_df.selectExpr("CAST(value AS STRING) AS json_value", "timestamp AS kafka_timestamp")
        .select(F.from_json("json_value", RIDE_EVENT_SCHEMA).alias("event"), "kafka_timestamp")
        .select("event.*", "kafka_timestamp")
    )


def clean_events(df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """
    Splits the stream into (valid_events, invalid_events).

    Invalid events (null zone_id, non-positive zone_id, unparseable
    event_time) are routed to a dead-letter path by the caller rather than
    silently dropped, matching Section 27 (Error Handling).
    """
    parsed = df.withColumn("event_ts", F.to_timestamp("event_time"))

    valid = parsed.filter(
        F.col("zone_id").isNotNull()
        & (F.col("zone_id") > 0)
        & F.col("event_ts").isNotNull()
        & F.col("rider_id").isNotNull()
    )
    invalid = parsed.filter(
        F.col("zone_id").isNull() | (F.col("zone_id") <= 0) | F.col("event_ts").isNull() | F.col("rider_id").isNull()
    )
    return valid, invalid


def compute_windowed_aggregates(df: DataFrame) -> DataFrame:
    """
    Groups valid events into sliding windows per zone and counts ride
    requests per window. Watermarking bounds how long the engine waits
    for late-arriving events before finalizing a window.
    """
    return (
        df.withWatermark("event_ts", WATERMARK_DELAY)
        .groupBy(
            F.window("event_ts", WINDOW_DURATION, SLIDE_DURATION),
            F.col("zone_id"),
        )
        .agg(F.count("event_id").alias("ride_count"))
        .select(
            F.col("zone_id"),
            F.col("window.start").alias("window_start"),
            F.col("window.end").alias("window_end"),
            F.col("ride_count"),
        )
    )


def add_derived_features(df: DataFrame) -> DataFrame:
    """Adds hour_of_day and is_weekend, derived from window_start."""
    is_weekend_udf = F.udf(is_weekend_from_day_of_week)

    return (
        df.withColumn("hour_of_day", F.hour("window_start"))
        .withColumn("day_of_week", F.dayofweek("window_start"))
        .withColumn("is_weekend", is_weekend_udf(F.col("day_of_week")))
        .drop("day_of_week")
    )


def compute_rolling_average(df: DataFrame) -> DataFrame:
    """
    Adds a rolling average of ride_count over the trailing
    ROLLING_WINDOW_MINUTES, computed per zone ordered by window_start.

    Implemented as a batch-style window function inside foreachBatch
    (see spark_job.py) since Structured Streaming does not support
    row-range window functions directly on an unbounded streaming
    DataFrame — this function is applied to each micro-batch's output
    after it has been aggregated.
    """
    from pyspark.sql.window import Window

    zone_window = (
        Window.partitionBy("zone_id")
        .orderBy(F.col("window_start").cast("long"))
        .rangeBetween(-ROLLING_WINDOW_MINUTES * 60, 0)
    )
    return df.withColumn("rolling_avg_15m", F.avg("ride_count").over(zone_window))


def build_feature_pipeline(raw_df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """
    Full pipeline entry point used by spark_job.py.
    Returns (features_df, invalid_events_df).
    """
    parsed = parse_raw_events(raw_df)
    valid, invalid = clean_events(parsed)
    windowed = compute_windowed_aggregates(valid)
    with_features = add_derived_features(windowed)
    return with_features, invalid
