"""
ml/train.py

Offline training script for the demand prediction model.

Run manually or on a schedule (e.g. weekly) — never as part of the live
streaming path. Matches Technical Documentation, Section 18.6 (Training
Process):
  - Reads historical zone_features from PostgreSQL.
  - Splits by TIME, never by random shuffling, to avoid leaking future
    information into training (the single most common mistake flagged
    in Section 33, Lessons Learned).
  - Evaluates with MAE / RMSE / R2 (Section 18.7).
  - Saves a versioned artifact via ml/model.py.
"""

import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

sys.path.append("/app")
from common.config import load_database_config, load_ml_config  # noqa: E402
from common.logging_config import get_logger  # noqa: E402
from ml.model import DemandModel, ModelMetadata, FEATURE_COLUMNS  # noqa: E402

logger = get_logger("ml-train")

TARGET_COLUMN = "next_window_ride_count"


def load_training_data(db_config) -> pd.DataFrame:
    """
    Loads historical zone_features and constructs the training target:
    the ride_count of the NEXT window for the same zone (i.e. "what
    actually happened 15 minutes later"), which is what the model is
    trying to predict ahead of time.
    """
    import sqlalchemy

    engine = sqlalchemy.create_engine(db_config.sqlalchemy_url)
    query = """
        SELECT zone_id, window_start, ride_count, rolling_avg_15m,
               hour_of_day, is_weekend, zone_historical_avg
        FROM zone_features
        ORDER BY zone_id, window_start
    """
    df = pd.read_sql(query, engine)

    df["next_window_ride_count"] = df.groupby("zone_id")["ride_count"].shift(-1)
    df = df.dropna(subset=[TARGET_COLUMN])
    return df


def time_based_split(df: pd.DataFrame, train_fraction: float = 0.8) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Splits strictly by window_start, not randomly — the last
    (1 - train_fraction) of the timeline becomes the test set. This
    prevents the model from ever training on data that occurs after
    what it is evaluated on.
    """
    df_sorted = df.sort_values("window_start")
    split_index = int(len(df_sorted) * train_fraction)
    train_df = df_sorted.iloc[:split_index]
    test_df = df_sorted.iloc[split_index:]
    return train_df, test_df


def train_and_evaluate(train_df: pd.DataFrame, test_df: pd.DataFrame):
    X_train = train_df[FEATURE_COLUMNS].fillna(0)
    y_train = train_df[TARGET_COLUMN]
    X_test = test_df[FEATURE_COLUMNS].fillna(0)
    y_test = test_df[TARGET_COLUMN]

    # Gradient boosting selected per Section 18.5 (Model Selection) — best
    # accuracy on tabular demand data among the evaluated candidates.
    estimator = GradientBoostingRegressor(
        n_estimators=200,
        max_depth=4,
        learning_rate=0.05,
        random_state=42,
    )
    estimator.fit(X_train, y_train)

    predictions = estimator.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)
    rmse = mean_squared_error(y_test, predictions) ** 0.5
    r2 = r2_score(y_test, predictions)

    logger.info(f"Evaluation -> MAE={mae:.3f}  RMSE={rmse:.3f}  R2={r2:.3f}")
    return estimator, mae, rmse, r2


def run() -> None:
    db_config = load_database_config()
    ml_config = load_ml_config()

    logger.info("Loading historical zone_features for training...")
    df = load_training_data(db_config)

    if len(df) < 50:
        logger.warning(
            f"Only {len(df)} labeled rows available — model quality will be "
            f"poor until more data accumulates. Proceeding anyway for demo purposes."
        )

    train_df, test_df = time_based_split(df)
    logger.info(f"Train rows: {len(train_df)}  Test rows: {len(test_df)}")

    estimator, mae, rmse, r2 = train_and_evaluate(train_df, test_df)

    version = datetime.now(timezone.utc).strftime("v%Y%m%d_%H%M%S")
    metadata = ModelMetadata(
        version=version,
        trained_at=datetime.now(timezone.utc).isoformat(),
        mae=mae,
        rmse=rmse,
        r2=r2,
    )
    model = DemandModel(estimator, metadata)
    artifact_dir = str(Path(ml_config.model_path).parent)
    model.save(model_dir=artifact_dir)
    logger.info(f"Saved model artifact version {version} to {artifact_dir}")


if __name__ == "__main__":
    run()
