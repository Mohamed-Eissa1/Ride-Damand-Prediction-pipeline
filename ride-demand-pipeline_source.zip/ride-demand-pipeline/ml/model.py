"""
ml/model.py

Thin wrapper around the trained model artifact.

Kept separate from train.py (which produces the artifact) and
scoring_service.py (which runs continuously) so the prediction logic
itself — given a feature row, produce a demand estimate — can be unit
tested with an in-memory model, without touching Postgres or a real
trained artifact.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import joblib

FEATURE_COLUMNS = [
    "ride_count",
    "rolling_avg_15m",
    "hour_of_day",
    "is_weekend",
    "zone_historical_avg",
]


@dataclass(frozen=True)
class ModelMetadata:
    version: str
    trained_at: str
    mae: float
    rmse: float
    r2: float


class DemandModel:
    """Wraps a scikit-learn regressor plus its versioned metadata."""

    def __init__(self, estimator, metadata: ModelMetadata):
        self.estimator = estimator
        self.metadata = metadata

    def predict_one(self, features: dict) -> float:
        """
        Predicts demand for a single feature row (a dict keyed by
        FEATURE_COLUMNS). Raises a clear error if a required feature is
        missing, rather than letting sklearn fail with an opaque shape error.
        """
        missing = [c for c in FEATURE_COLUMNS if c not in features]
        if missing:
            raise ValueError(f"Missing required features for prediction: {missing}")

        row = [
            [
                features["ride_count"],
                features["rolling_avg_15m"] if features["rolling_avg_15m"] is not None else features["ride_count"],
                features["hour_of_day"],
                int(bool(features["is_weekend"])),
                (
                    features["zone_historical_avg"]
                    if features["zone_historical_avg"] is not None
                    else features["ride_count"]
                ),
            ]
        ]
        prediction = self.estimator.predict(row)[0]
        return max(0.0, float(prediction))  # demand cannot be negative

    def save(self, model_dir: str) -> None:
        Path(model_dir).mkdir(parents=True, exist_ok=True)
        joblib.dump(self.estimator, Path(model_dir) / f"demand_model_{self.metadata.version}.pkl")
        with open(Path(model_dir) / f"demand_model_{self.metadata.version}.meta.json", "w") as f:
            json.dump(self.metadata.__dict__, f, indent=2)

    @staticmethod
    def load(model_path: str) -> "DemandModel":
        model_path = Path(model_path)
        estimator = joblib.load(model_path)
        meta_path = model_path.with_suffix("").with_suffix(".meta.json")
        with open(meta_path) as f:
            meta_dict = json.load(f)
        return DemandModel(estimator, ModelMetadata(**meta_dict))
