"""
ml/scoring_service.py

A small, always-on worker that periodically reads the latest rows from
zone_features, scores them with the currently deployed model, and
upserts results into zone_predictions.

Deliberately a standalone process rather than embedded inside the Spark
job (Section 18.8, Deployment) — this means the model can be reloaded
or rolled back independently of the streaming pipeline, and a scoring
bug can never crash the Spark job that's producing features.
"""

import sys
import time

sys.path.append("/app")
from common.config import load_database_config, load_ml_config  # noqa: E402
from common.logging_config import get_logger  # noqa: E402
from ml.model import DemandModel  # noqa: E402

logger = get_logger("ml-scoring")

POLL_INTERVAL_SECONDS = 30


def fetch_unscored_features(conn, model_version: str):
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT f.feature_id, f.zone_id, f.window_start, f.window_end,
                   f.ride_count, f.rolling_avg_15m, f.hour_of_day,
                   f.is_weekend, f.zone_historical_avg
            FROM zone_features f
            LEFT JOIN zone_predictions p
                ON p.zone_id = f.zone_id
               AND p.window_start = f.window_start
               AND p.model_version = %s
            WHERE p.prediction_id IS NULL
            ORDER BY f.window_start
            LIMIT 500
        """,
            (model_version,),
        )
        columns = [desc[0] for desc in cur.description]
        return [dict(zip(columns, row)) for row in cur.fetchall()]


def write_prediction(conn, zone_id, window_start, window_end, predicted_demand, model_version):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO zone_predictions (
                zone_id, predicted_demand, window_start, window_end, model_version
            ) VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (zone_id, window_start, model_version) DO UPDATE SET
                predicted_demand = EXCLUDED.predicted_demand,
                created_at = now();
        """,
            (zone_id, predicted_demand, window_start, window_end, model_version),
        )
    conn.commit()


def score_pending_features(conn, model: DemandModel) -> int:
    rows = fetch_unscored_features(conn, model.metadata.version)
    if not rows:
        return 0

    scored_count = 0
    for row in rows:
        try:
            predicted_demand = model.predict_one(row)
            write_prediction(
                conn,
                zone_id=row["zone_id"],
                window_start=row["window_start"],
                window_end=row["window_end"],
                predicted_demand=predicted_demand,
                model_version=model.metadata.version,
            )
            scored_count += 1
        except Exception:
            logger.exception(f"Failed to score/write prediction for zone {row.get('zone_id')}, skipping row")
            continue

    return scored_count


def run() -> None:
    import psycopg2

    db_config = load_database_config()
    ml_config = load_ml_config()

    logger.info(f"Loading model from {ml_config.model_path}")
    try:
        model = DemandModel.load(ml_config.model_path)
    except FileNotFoundError:
        logger.error(
            f"No model artifact found at {ml_config.model_path}. "
            f"Run ml/train.py at least once before starting the scoring service."
        )
        sys.exit(1)

    logger.info(f"Scoring service started with model version {model.metadata.version}")

    while True:
        try:
            conn = psycopg2.connect(
                host=db_config.host,
                port=db_config.port,
                dbname=db_config.name,
                user=db_config.user,
                password=db_config.password,
            )
            try:
                scored = score_pending_features(conn, model)
                if scored:
                    logger.info(f"Scored {scored} new feature windows")
            finally:
                conn.close()
        except Exception:
            logger.exception("Scoring cycle failed, will retry on next interval")

        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    run()
