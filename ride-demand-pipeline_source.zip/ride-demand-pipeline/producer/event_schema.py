"""
producer/event_schema.py

Defines the canonical shape of a ride-request event.

This is the single most important contract in the whole system: Kafka has
no built-in schema enforcement, so this dataclass + its to_dict/validate
methods are what keep the producer, the debug consumer, and the Spark job
all agreeing on the same event shape (see Technical Documentation,
Section 16 - Apache Kafka).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone


class InvalidRideEventError(ValueError):
    """Raised when an event fails schema validation before being published."""


@dataclass(frozen=True)
class RideRequestEvent:
    event_id: str
    zone_id: int
    rider_id: str
    event_time: str  # ISO-8601 UTC string, e.g. 2026-07-07T18:03:21.123Z

    @staticmethod
    def create(zone_id: int, rider_id: str) -> "RideRequestEvent":
        return RideRequestEvent(
            event_id=str(uuid.uuid4()),
            zone_id=zone_id,
            rider_id=rider_id,
            event_time=datetime.now(timezone.utc).isoformat(),
        )

    def validate(self) -> None:
        if not isinstance(self.zone_id, int) or self.zone_id <= 0:
            raise InvalidRideEventError(f"zone_id must be a positive integer, got {self.zone_id!r}")
        if not self.rider_id:
            raise InvalidRideEventError("rider_id must not be empty")
        if not self.event_time:
            raise InvalidRideEventError("event_time must not be empty")

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json_bytes(self) -> bytes:
        import json

        return json.dumps(self.to_dict()).encode("utf-8")

    @staticmethod
    def from_dict(data: dict) -> "RideRequestEvent":
        try:
            event = RideRequestEvent(
                event_id=data["event_id"],
                zone_id=int(data["zone_id"]),
                rider_id=data["rider_id"],
                event_time=data["event_time"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise InvalidRideEventError(f"Malformed event payload: {exc}") from exc
        event.validate()
        return event
