"""
producer/consumer.py

A lightweight, standalone Kafka consumer — separate from the Spark
Structured Streaming job — used to manually verify that events are
flowing correctly through Kafka during development and troubleshooting.

This is NOT part of the production data path (Spark consumes the topic
for real processing). It exists purely as an operational/debugging tool,
the equivalent of `kafka-console-consumer.sh` but with schema validation
and dead-letter routing built in, so a team member can quickly answer
"is Kafka actually receiving valid events right now?" without spinning up
Spark.
"""

import sys

from confluent_kafka import Consumer, KafkaError, Producer

sys.path.append("/app")
from common.config import load_kafka_config  # noqa: E402
from common.logging_config import get_logger  # noqa: E402
from producer.event_schema import RideRequestEvent, InvalidRideEventError  # noqa: E402
import json  # noqa: E402

logger = get_logger("debug-consumer")


def build_consumer(kafka_config) -> Consumer:
    return Consumer(
        {
            "bootstrap.servers": kafka_config.bootstrap_servers,
            "group.id": "debug-consumer-group",
            "auto.offset.reset": "latest",
            "enable.auto.commit": True,
        }
    )


def build_dlq_producer(kafka_config) -> Producer:
    return Producer({"bootstrap.servers": kafka_config.bootstrap_servers})


def run(max_messages: int | None = None) -> None:
    kafka_config = load_kafka_config()
    consumer = build_consumer(kafka_config)
    dlq_producer = build_dlq_producer(kafka_config)
    consumer.subscribe([kafka_config.topic_ride_requests])

    logger.info(f"Listening on topic '{kafka_config.topic_ride_requests}' (Ctrl+C to stop)")
    processed = 0

    try:
        while max_messages is None or processed < max_messages:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    continue
                logger.error(f"Consumer error: {msg.error()}")
                continue

            try:
                payload = json.loads(msg.value().decode("utf-8"))
                event = RideRequestEvent.from_dict(payload)
                logger.info(f"OK  zone={event.zone_id} rider={event.rider_id} time={event.event_time}")
                processed += 1
            except (InvalidRideEventError, json.JSONDecodeError) as exc:
                logger.warning(f"Malformed event routed to DLQ: {exc}")
                dlq_producer.produce(kafka_config.topic_dead_letter, value=msg.value())
                dlq_producer.poll(0)

    except KeyboardInterrupt:
        logger.info("Stopped by user")
    finally:
        consumer.close()
        dlq_producer.flush(timeout=5)
        logger.info(f"Total valid events observed: {processed}")


if __name__ == "__main__":
    run()
