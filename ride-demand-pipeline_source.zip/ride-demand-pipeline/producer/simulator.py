"""
producer/simulator.py

Simulates a ride-hailing app publishing ride-request events to Kafka.

In production this role is played by the actual rider-facing application;
here it is a controlled simulator so the rest of the pipeline can be built
and tested without a real mobile app. The simulation logic is intentionally
isolated in generate_event() so it can be swapped for a real event source
later without touching the Kafka publishing logic.

Enterprise practices demonstrated here:
  - Producer is keyed by zone_id, matching the partitioning strategy
    documented in Section 16.5 (Partitions), so all events for one zone
    stay in order on the same partition.
  - acks='all' + retries + delivery callback -> the producer confirms
    every event was durably written before considering it sent.
  - Graceful shutdown on SIGINT/SIGTERM so no in-flight message is lost
    when the container is stopped.
"""

import random
import signal
import sys
import time

from confluent_kafka import Producer

sys.path.append("/app")  # allows `from common...` imports when run inside the container
from common.config import load_kafka_config  # noqa: E402
from common.logging_config import get_logger  # noqa: E402
from producer.event_schema import RideRequestEvent  # noqa: E402

logger = get_logger("producer")

# Demo zone IDs — must match db/migrations/002_seed_zones.sql
ZONE_IDS = list(range(1, 9))

_shutdown_requested = False


def _handle_shutdown(signum, frame):
    global _shutdown_requested
    logger.info("Shutdown signal received, finishing in-flight deliveries...")
    _shutdown_requested = True


def _delivery_callback(err, msg):
    if err is not None:
        logger.error(f"Delivery failed for event on partition key={msg.key()}: {err}")
    else:
        logger.debug(f"Delivered event to {msg.topic()} [partition {msg.partition()}]")


def build_producer() -> Producer:
    kafka_config = load_kafka_config()
    return Producer(
        {
            "bootstrap.servers": kafka_config.bootstrap_servers,
            "acks": "all",
            "retries": 5,
            "retry.backoff.ms": 200,
            "enable.idempotence": True,
        }
    )


def generate_event() -> RideRequestEvent:
    """Generates one synthetic ride-request event with a randomly weighted zone."""
    # Weighted so some zones (e.g. Downtown) receive more traffic than others,
    # producing a more realistic demand distribution for the ML layer to learn from.
    weights = [3, 2, 2, 2, 1, 2, 1, 2]
    zone_id = random.choices(ZONE_IDS, weights=weights, k=1)[0]
    rider_id = f"rider_{random.randint(1, 5000):05d}"
    return RideRequestEvent.create(zone_id=zone_id, rider_id=rider_id)


def run(events_per_second: float = 5.0) -> None:
    kafka_config = load_kafka_config()
    producer = build_producer()

    signal.signal(signal.SIGINT, _handle_shutdown)
    signal.signal(signal.SIGTERM, _handle_shutdown)

    logger.info(
        f"Starting ride request simulator -> topic '{kafka_config.topic_ride_requests}' "
        f"at ~{events_per_second} events/sec"
    )

    published_count = 0
    interval = 1.0 / events_per_second

    while not _shutdown_requested:
        try:
            event = generate_event()
            event.validate()

            producer.produce(
                topic=kafka_config.topic_ride_requests,
                key=str(event.zone_id).encode("utf-8"),
                value=event.to_json_bytes(),
                callback=_delivery_callback,
            )
            producer.poll(0)  # trigger any pending delivery callbacks
            published_count += 1

            if published_count % 100 == 0:
                logger.info(f"Published {published_count} events so far")

            time.sleep(interval)

        except Exception:
            # A single bad event should never crash the whole simulator.
            logger.exception("Unexpected error while producing event, continuing")
            time.sleep(interval)

    logger.info("Flushing remaining messages before exit...")
    producer.flush(timeout=10)
    logger.info(f"Simulator stopped cleanly. Total events published: {published_count}")


if __name__ == "__main__":
    run()
