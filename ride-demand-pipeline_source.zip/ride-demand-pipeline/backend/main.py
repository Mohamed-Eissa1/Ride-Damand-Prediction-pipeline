"""
backend/main.py

FastAPI application exposing ride demand predictions to the dashboard
and any other consumer. Matches Technical Documentation, Section 20
(API Documentation).

Endpoints:
    GET /v1/health                       - service + DB health check
    GET /v1/zones                        - zone reference data
    GET /v1/predictions/all              - latest prediction per zone
    GET /v1/predictions/zone/{zone_id}   - latest prediction for one zone

Security: a simple API key header (Section 24.1, Authentication) guards
every endpoint except /v1/health, which must stay reachable for
container healthchecks without a key.
"""

import sys
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

sys.path.append("/app")
from backend import database  # noqa: E402
from backend.schemas import ErrorResponse, HealthResponse, PredictionResponse, ZoneResponse  # noqa: E402
from common.config import load_api_config, load_database_config  # noqa: E402
from common.logging_config import get_logger  # noqa: E402

logger = get_logger("backend")


@asynccontextmanager
async def lifespan(app: FastAPI):
    db_config = load_database_config()
    database.init_pool(db_config)
    logger.info("Database connection pool initialized")
    yield
    logger.info("Shutting down API service")


app = FastAPI(
    title="Ride Demand Prediction API",
    version="1.0.0",
    description="Serves real-time ride demand predictions produced by the streaming + ML pipeline.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tightened via reverse proxy config in a real production deployment
    allow_methods=["GET"],
    allow_headers=["*"],
)


def require_api_key(x_api_key: str = Header(default="")) -> None:
    api_config = load_api_config()
    if x_api_key != api_config.api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )


@app.get("/v1/health", response_model=HealthResponse, tags=["Health"])
def health() -> HealthResponse:
    db_ok = database.check_connection()
    return HealthResponse(status="ok" if db_ok else "degraded", database_connected=db_ok)


@app.get(
    "/v1/zones",
    response_model=list[ZoneResponse],
    responses={401: {"model": ErrorResponse}},
    dependencies=[Depends(require_api_key)],
    tags=["Zones"],
)
def get_zones() -> list[ZoneResponse]:
    try:
        rows = database.fetch_all_zones()
        return [ZoneResponse(**row) for row in rows]
    except Exception:
        logger.exception("Failed to fetch zones")
        raise HTTPException(status_code=500, detail="Failed to fetch zones")


@app.get(
    "/v1/predictions/all",
    response_model=list[PredictionResponse],
    responses={401: {"model": ErrorResponse}},
    dependencies=[Depends(require_api_key)],
    tags=["Predictions"],
)
def get_all_predictions() -> list[PredictionResponse]:
    try:
        rows = database.fetch_latest_predictions()
        return [PredictionResponse(**row) for row in rows]
    except Exception:
        logger.exception("Failed to fetch predictions")
        raise HTTPException(status_code=500, detail="Failed to fetch predictions")


@app.get(
    "/v1/predictions/zone/{zone_id}",
    response_model=PredictionResponse,
    responses={404: {"model": ErrorResponse}, 401: {"model": ErrorResponse}},
    dependencies=[Depends(require_api_key)],
    tags=["Predictions"],
)
def get_prediction_for_zone(zone_id: int) -> PredictionResponse:
    try:
        row = database.fetch_latest_prediction_for_zone(zone_id)
    except Exception:
        logger.exception(f"Failed to fetch prediction for zone {zone_id}")
        raise HTTPException(status_code=500, detail="Failed to fetch prediction")

    if row is None:
        raise HTTPException(status_code=404, detail=f"No prediction found for zone_id={zone_id}")
    return PredictionResponse(**row)
