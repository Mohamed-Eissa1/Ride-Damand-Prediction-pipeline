"""
backend/database.py

Database access layer for the API.

Uses a psycopg2 connection pool with parameterized SQL rather than a
full ORM: the API's read patterns are simple and fixed (Section 20.2),
so a thin repository layer keeps queries auditable and trivially easy
to mock in unit tests, while parameterization prevents SQL injection
(Section 24.4, API Security).
"""

from __future__ import annotations

import logging
from contextlib import contextmanager

import psycopg2
import psycopg2.pool
from psycopg2.extras import RealDictCursor

from common.config import DatabaseConfig

logger = logging.getLogger("backend")

_pool: psycopg2.pool.SimpleConnectionPool | None = None


def init_pool(db_config: DatabaseConfig, minconn: int = 1, maxconn: int = 10) -> None:
    global _pool
    _pool = psycopg2.pool.SimpleConnectionPool(
        minconn,
        maxconn,
        host=db_config.host,
        port=db_config.port,
        dbname=db_config.name,
        user=db_config.user,
        password=db_config.password,
    )


@contextmanager
def get_connection():
    if _pool is None:
        raise RuntimeError("Database pool not initialized — call init_pool() at startup")
    conn = _pool.getconn()
    try:
        yield conn
    finally:
        _pool.putconn(conn)


def check_connection() -> bool:
    try:
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1;")
        return True
    except Exception:
        logger.exception("Database health check failed")
        return False


def fetch_all_zones() -> list[dict]:
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT zone_id, zone_name, boundary_lat, boundary_lng FROM zones ORDER BY zone_id;")
            return [dict(row) for row in cur.fetchall()]


def fetch_latest_predictions() -> list[dict]:
    """
    Latest prediction per zone: the most recent window_start for each
    zone_id, joined with zone metadata for display purposes.
    """
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT DISTINCT ON (p.zone_id)
                    p.zone_id, z.zone_name, p.predicted_demand,
                    p.window_start, p.window_end, p.model_version
                FROM zone_predictions p
                JOIN zones z ON z.zone_id = p.zone_id
                ORDER BY p.zone_id, p.window_start DESC;
            """)
            return [dict(row) for row in cur.fetchall()]


def fetch_latest_prediction_for_zone(zone_id: int) -> dict | None:
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                SELECT p.zone_id, z.zone_name, p.predicted_demand,
                       p.window_start, p.window_end, p.model_version
                FROM zone_predictions p
                JOIN zones z ON z.zone_id = p.zone_id
                WHERE p.zone_id = %s
                ORDER BY p.window_start DESC
                LIMIT 1;
            """,
                (zone_id,),
            )
            row = cur.fetchone()
            return dict(row) if row else None
