"""
backend/schemas.py

Pydantic models defining the API's request/response contracts.

Matches Technical Documentation, Section 20 (API Documentation). Keeping
these separate from the database query layer (database.py) means the API
contract can be reviewed and versioned independently of how data happens
to be stored.
"""

from datetime import datetime

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str = Field(..., examples=["ok"])
    database_connected: bool


class ZoneResponse(BaseModel):
    zone_id: int
    zone_name: str
    boundary_lat: float
    boundary_lng: float


class PredictionResponse(BaseModel):
    zone_id: int
    zone_name: str
    predicted_demand: float
    window_start: datetime
    window_end: datetime
    model_version: str


class ErrorResponse(BaseModel):
    detail: str
